Rails.application.routes.draw do
  namespace :administrative do
    resources :administrators do
      collection do
        get 'block_administrator'
      end
    end
    resources :companies do
      get 'change_cities'
      resources :employees do
        collection do
          get 'lock_employee'
          get 'unlock_employee'
        end
      end
      collection do
        get 'clinics'
        get 'pharmacies'
        get 'remove_companie'
        get 'change_cities'
        get 'recipes'
        get 'quotations'
      end
    end
    resources :reports do
      collection do
        get 'total_recipes_generate_form'
        get 'total_recipes_generate_result'
        post 'total_recipes_generate_result'
        get 'total_quotations_generate_form'
        get 'total_quotations_generate_result'
        post 'total_quotations_generate_result'
      end
    end
    get     'login/login_administrator'
    post    'login/authenticate_administrator'
    get     'login/destroy'
    delete  'login/destroy'
  end

  namespace :administrative_patient do
    resources :recipes do
      collection do
        get 'invalid_recipe'
      end
    end
    resources :recipes_dependents
    resources :quotations do
      collection do
        get 'quotations_accept'
        get 'quotations_refuse'
      end
    end
    resources :quotations_dependents do
      collection do
        get 'quotations_accept'
        get 'quotations_refuse'
      end
    end
    resources :patients do
      resources :dependents, as: :patients
      collection do
        get 'remove_patient'
      end
    get 'change_cities'
    end
    get     'login/login_patient'
    post    'login/authenticate_patient'
    get     'login/destroy'
    delete  'login/destroy'
  end

  namespace :administrative_employee do
    resources :employees
    resources :recipes do
      collection do
        get 'search'
        get 'invalid_recipe'
      end
    end
    resources :quotations
    resources :patients do
      collection do
        get 'change_cities'
      end
    end
    resources :quotations_requests do
      resources :quotations
    end
    resources :reports do
      collection do
        get 'recipes_medics'
        get 'recipes_medics_result'
        post 'recipes_medics_result'
        get 'quotation_employees'
        get 'quotation_employees_result'
      end
    end
    get     'login/login_employee'
    post    'login/authenticate_employee'
    get     'login/destroy'
    delete  'login/destroy'
  end
  get 'site' => "site#index"
  post 'contact_me' => 'site#contact_me'

  root to: 'site#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
