# FARMAMAIS
Projeto de Final de Curso UMC

### Coisas uteis:

##### Assistir as aulas da udemy a partir da aula 99

Rolou algum erro, copiem as palavras chave ou o retorno do erro e pesquisem.
melhor forma de aprender a programar. Temos que ser mais autodidatas. Sem medo. Se zuar a aplicacao so clonar novamente.

#### Subir a application: rails s
#### Subir o console do ruby: rails c

#### Ativar postgres: sudo postgresql-setup initdb
#### Subir o postgres: sudo systemctl start postgresql-11
#### Restartar o postgres: sudo systemctl restart postgresql-11
#### Parar o postgres: sudo systemctl stop postgresql-11
#### Listar Bancos de Dados do Computador: psql -l 
#### Entrar Banco de Dados: psql farmamais_development
#### Listar Tabelas: \dt 

Lembrar de verificar a versao do ruby. Estamos usando a 2.6.0
Caso a sua seja diferente atualize os arquivos Gemfile e .ruby-version com o ruby que voce tenha instalado

##### Rode um bundle caso precise atualizar os arquivos dito acima.

### Comandos do GIT:
##### - git status = lista os arquivos modificados
##### - git add nome_do_arquivo = adiciona o arquivo para o commit
##### - git commit -s = cria o commit com a sua assinatura do email.
##### - git push origin master = atualiza nosso repositorio aqui no git com seus commits/arquivos modificados
##### - git pull --rebase = Atualiza seu projeto local com as atualizacoes do nosso repositorio
##### - git stash = salva os arquivos local (Deem uma pesquisada)
##### - git log = lista os commits da branch
##### - git checkout nome_do_arquivo = limpa todas as modificacoes do arquivo.


###### Boa Sorte a todos e que o StackOverFlow nos ilumine.
