BEGIN;
  CREATE TABLE deficiencies_patients(
    id SERIAL PRIMARY KEY,
    patient_id INTEGER REFERENCES patients(id),
    deficiency_id INTEGER REFERENCES deficiencies(id)
  );
COMMIT;
