BEGIN;
  ALTER TABLE quotations_requests ADD COLUMN active BOOLEAN DEFAULT true;
COMMIT;
