BEGIN;
  CREATE TABLE remedies_recipes (
    id SERIAL PRIMARY KEY,
    recipe_id INTEGER REFERENCES recipes(id),
    remedy_id INTEGER REFERENCES remedies(id),
    quantity INTEGER,
    measured_unit_id INTEGER REFERENCES measured_units(id)
  );
COMMIT;
