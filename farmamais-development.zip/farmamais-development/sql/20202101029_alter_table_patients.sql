BEGIN;
  ALTER TABLE patients DROP COLUMN patients_address_id;
  ALTER TABLE patients DROP COLUMN patient_holder_id;
  ALTER TABLE patients DROP COLUMN patients_holder_id;
  ALTER TABLE patients ADD COLUMN holder_id INTEGER REFERENCES patients(id);
COMMIT;
