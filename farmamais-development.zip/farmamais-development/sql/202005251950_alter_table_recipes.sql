BEGIN;
  ALTER TABLE recipes RENAME COLUMN send_to_quotation TO print;
COMMIT;
