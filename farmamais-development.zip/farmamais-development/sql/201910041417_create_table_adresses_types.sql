BEGIN;
  CREATE TABLE adresses_types(
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO adresses_types(description) VALUES ('Residencial');
  INSERT INTO adresses_types(description) VALUES ('Comercial');
COMMIT;
