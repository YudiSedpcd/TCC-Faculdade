BEGIN;
  CREATE TABLE measured_units(
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
  INSERT INTO measured_units VALUES (1,'Porcentagem');
  INSERT INTO measured_units VALUES (2,'Capsulas');
  INSERT INTO measured_units VALUES (3,'Miligramas');
  INSERT INTO measured_units VALUES (4,'Milílitro');
  INSERT INTO measured_units VALUES (5,'Gotas');
COMMIT;
