BEGIN;
  CREATE TABLE patients_emails (
    id SERIAL PRIMARY KEY,
    email VARCHAR,
    patient_id INTEGER REFERENCES patients(id),
    emails_type_id INTEGER REFERENCES emails_types(id),
    created_in TIMESTAMP
  );
COMMIT;
