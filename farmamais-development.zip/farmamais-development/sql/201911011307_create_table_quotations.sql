BEGIN;
  CREATE TABLE quotations(
    id SERIAL PRIMARY KEY,
    description VARCHAR,
    value NUMERIC,
    active BOOLEAN,
    approved BOOLEAN,
    disapproved BOOLEAN,
    employee_id INTEGER REFERENCES employees(id),
    pharmacy_id INTEGER REFERENCES companies(id),
    clinic_id INTEGER REFERENCES companies(id),
    recipe_id INTEGER REFERENCES recipes(id),
    patient_id INTEGER REFERENCES patients(id),
    quotations_request_id INTEGER REFERENCES quotations_requests(id),
    due_date TIMESTAMP,
    created_in TIMESTAMP
  );
COMMIT;
