BEGIN;
  CREATE TABLE telephones_types(
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO telephones_types VALUES (1, 'Particular');
  INSERT INTO telephones_types VALUES (2, 'Comercial');
  INSERT INTO telephones_types VALUES (3, 'Recado');
COMMIT;
