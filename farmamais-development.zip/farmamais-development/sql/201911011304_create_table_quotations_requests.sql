BEGIN;
  CREATE TABLE quotations_requests (
    id SERIAL PRIMARY KEY,
    clinic_id INTEGER REFERENCES companies(id),
    recipe_id INTEGER REFERENCES recipes(id),
    patient_id INTEGER REFERENCES patients(id),
    pharmacy_id INTEGER REFERENCES companies(id),
    employee_id INTEGER REFERENCES employees(id),
    generate_quotation BOOLEAN,
    created_in TIMESTAMP
  );
COMMIT;
