BEGIN;
  ALTER TABLE companies_adresses DROP COLUMN city;
  ALTER TABLE companies_adresses ADD COLUMN city_id INTEGER REFERENCES cities(id);
COMMIT;
BEGIN;
  ALTER TABLE patients_adresses DROP COLUMN city;
  ALTER TABLE patients_adresses ADD COLUMN city_id INTEGER REFERENCES cities(id);
COMMIT;
