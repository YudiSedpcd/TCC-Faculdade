BEGIN;
  CREATE TABLE patients (
    id SERIAL PRIMARY KEY,
    name VARCHAR,
    last_name VARCHAR,
    cpf VARCHAR UNIQUE,
    birth_date DATE,
    login VARCHAR,
    password VARCHAR,
    blocked BOOLEAN DEFAULT FALSE,
    created_in TIMESTAMP,
    dependent BOOLEAN DEFAULT FALSE,
    sexo_id INTEGER REFERENCES sexos(id)
  );
COMMIT;
