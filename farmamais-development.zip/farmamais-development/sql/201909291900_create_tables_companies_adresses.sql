BEGIN;
  CREATE TABLE companies_adresses(
    id SERIAL PRIMARY KEY,
    street VARCHAR,
    number VARCHAR,
    district VARCHAR,
    city VARCHAR,
    cep VARCHAR,
    state_id INTEGER REFERENCES states(id),
    companie_id INTEGER REFERENCES companies(id)
  );
COMMIT;
