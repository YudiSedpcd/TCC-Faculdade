BEGIN;
  CREATE TABLE patients_adresses(
    id SERIAL PRIMARY KEY,
    street VARCHAR,
    number VARCHAR,
    district VARCHAR,
    city VARCHAR,
    cep VARCHAR,
    state_id INTEGER REFERENCES states(id),
    patient_id INTEGER REFERENCES patients(id)
  );
COMMIT;
