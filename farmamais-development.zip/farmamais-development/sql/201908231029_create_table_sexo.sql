BEGIN;
  CREATE TABLE sexos(
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO sexos (description) VALUES ('Feminino');
  INSERT INTO sexos (description) VALUES ('Masculino');
COMMIT;
