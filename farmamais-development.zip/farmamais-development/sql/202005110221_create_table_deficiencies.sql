BEGIN;
  CREATE TABLE deficiencies(
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO deficiencies(description) VALUES ('Auditiva');
  INSERT INTO deficiencies(description) VALUES ('Física');
  INSERT INTO deficiencies(description) VALUES ('Mental');
  INSERT INTO deficiencies(description) VALUES ('Visual');
COMMIT;
