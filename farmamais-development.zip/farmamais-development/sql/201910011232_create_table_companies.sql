BEGIN;
  CREATE TABLE companies (
    id SERIAL PRIMARY KEY,
    fantasy_name VARCHAR,
    corporate_name VARCHAR,
    cnpj VARCHAR UNIQUE,
    color_theme VARCHAR,
    companies_type_id INTEGER REFERENCES companies_types(id),
    companies_status_id INTEGER REFERENCES companies_statuses(id),
    created_in TIMESTAMP
  );
COMMIT;
