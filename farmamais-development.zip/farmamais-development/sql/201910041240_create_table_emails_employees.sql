BEGIN;
  CREATE TABLE employees_emails (
    id SERIAL PRIMARY KEY,
    email VARCHAR,
    employee_id INTEGER REFERENCES employees(id),
    emails_type_id INTEGER REFERENCES emails_types(id),
    created_in TIMESTAMP
  );
COMMIT;
