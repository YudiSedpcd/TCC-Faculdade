BEGIN;
  CREATE TABLE access_levels (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO access_levels VALUES (1, 'CEO');
  INSERT INTO access_levels VALUES (2, 'Funcionário');
  INSERT INTO access_levels VALUES (3, 'Observador');
COMMIT;
