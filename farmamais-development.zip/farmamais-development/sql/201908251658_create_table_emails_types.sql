BEGIN;
  CREATE TABLE emails_types (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO emails_types VALUES (1, 'Particular');
  INSERT INTO emails_types VALUES (2, 'Empresarial');
COMMIT;
