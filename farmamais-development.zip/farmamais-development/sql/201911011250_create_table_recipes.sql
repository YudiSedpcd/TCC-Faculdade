BEGIN;
  CREATE TABLE recipes (
    id SERIAL PRIMARY KEY,
    description VARCHAR,
    generate_quotation BOOLEAN DEFAULT true,
    send_to_quotation BOOLEAN DEFAULT false,
    doctors_prescription VARCHAR,
    patient_id INTEGER REFERENCES patients(id),
    clinic_id INTEGER REFERENCES companies(id),
    employee_id INTEGER REFERENCES employees(id),
    created_in TIMESTAMP
  );
COMMIT;
