BEGIN;
  CREATE TABLE companies_telephones(
    id SERIAL PRIMARY KEY,
    telephone VARCHAR,
    companie_id INTEGER REFERENCES companies(id),
    telephones_type_id INTEGER REFERENCES telephones_types(id),
    created_in TIMESTAMP
  );
COMMIT;
