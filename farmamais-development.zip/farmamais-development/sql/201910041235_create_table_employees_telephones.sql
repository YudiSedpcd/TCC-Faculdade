BEGIN;
  CREATE TABLE employees_telephones(
    id SERIAL PRIMARY KEY,
    telephone VARCHAR,
    employee_id INTEGER REFERENCES employees(id),
    telephones_type_id INTEGER REFERENCES telephones_types(id),
    created_in TIMESTAMP
  );
COMMIT;
