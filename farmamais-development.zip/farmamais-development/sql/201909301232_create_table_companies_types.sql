BEGIN;
  CREATE TABLE companies_types (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO companies_types VALUES(1,'Clinica');
  INSERT INTO companies_types VALUES(2,'Farmacia');
COMMIT;
