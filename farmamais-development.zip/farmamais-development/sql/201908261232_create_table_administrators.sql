BEGIN;
  CREATE TABLE administrators (
    id SERIAL PRIMARY KEY,
    name VARCHAR,
    last_name VARCHAR,
    login VARCHAR,
    password VARCHAR,
    blocked BOOLEAN DEFAULT FALSE,
    access_level INTEGER REFERENCES access_levels(id),
    created_in TIMESTAMP
  );
COMMIT;

BEGIN;
  INSERT INTO administrators (name, last_name, login, password) VALUES ('Administrador', 'FarmaMais', 'admin', '111');
COMMIT;
