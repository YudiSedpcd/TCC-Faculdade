BEGIN;
  CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    name VARCHAR,
    last_name VARCHAR,
    role VARCHAR,
    login VARCHAR,
    password VARCHAR,
    blocked BOOLEAN DEFAULT FALSE,
    access_level INTEGER REFERENCES access_levels(id),
    companie_id INTEGER REFERENCES companies (id),
    employees_type_id INTEGER REFERENCES employees_types (id),
    created_in TIMESTAMP
  );
COMMIT;
