BEGIN;
  CREATE TABLE cities(
    id SERIAL PRIMARY KEY,
    city VARCHAR,
    state_id INTEGER REFERENCES states(id)
  );
COMMIT;

-- \COPY cities (state_id, city) FROM '/home/rnascimento/farmamais/listacidades.csv' delimiter ',' csv;
-- \COPY cities (state_id, city) FROM '/home/gabrielazarcos/Documentos/listacidades.csv' delimiter ',' csv;

