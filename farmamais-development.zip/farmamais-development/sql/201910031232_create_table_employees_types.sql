BEGIN;
  CREATE TABLE employees_types (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO employees_types VALUES (1, 'Médico');
  INSERT INTO employees_types VALUES (2, 'Atendente');
  INSERT INTO employees_types VALUES (3, 'Administrativo');
COMMIT;
