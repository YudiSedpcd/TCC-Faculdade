BEGIN;
  ALTER TABLE patients ADD COLUMN deficient BOOLEAN DEFAULT false;
  ALTER TABLE patients ADD COLUMN description_deficiencies VARCHAR;
COMMIT;
