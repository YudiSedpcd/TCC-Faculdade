BEGIN;
  CREATE TABLE administrators_emails (
    id SERIAL PRIMARY KEY,
    email VARCHAR,
    administrator_id INTEGER REFERENCES administrators(id),
    emails_type_id INTEGER REFERENCES emails_types(id),
    created_in TIMESTAMP
  );
COMMIT;
