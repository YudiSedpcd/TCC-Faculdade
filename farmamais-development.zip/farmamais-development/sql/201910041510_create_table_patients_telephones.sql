BEGIN;
  CREATE TABLE patients_telephones(
    id SERIAL PRIMARY KEY,
    telephone VARCHAR,
    patient_id INTEGER REFERENCES patients(id),
    telephones_type_id INTEGER REFERENCES telephones_types(id),
    created_in TIMESTAMP
  );
COMMIT;
