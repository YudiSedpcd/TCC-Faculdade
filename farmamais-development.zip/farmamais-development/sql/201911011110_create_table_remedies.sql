BEGIN;
  CREATE TABLE remedies (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  -- Lembrar de Ajustar o Caminho correto para o Comando abaixo
  -- \COPY remedies (description) FROM '/Users/raphael.nascimento/farmamais/listaBaseComponentes.csv' delimiter ',' csv;
  -- \COPY remedies (description) FROM '/home/rnascimento/Documentos/listaBaseComponentes.csv' delimiter ',' csv;
  -- \COPY remedies (description) FROM '/home/gabrielazarcos/Documentos/listaBaseComponentes.csv' delimiter ',' csv;
COMMIT;
