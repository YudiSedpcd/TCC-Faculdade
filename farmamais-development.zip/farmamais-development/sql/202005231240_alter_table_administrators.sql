BEGIN;
  ALTER TABLE administrators DROP COLUMN access_level;
  ALTER TABLE administrators ADD COLUMN access_level_id INTEGER REFERENCES access_levels(id);
COMMIT;
