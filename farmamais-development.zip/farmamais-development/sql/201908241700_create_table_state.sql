BEGIN;
  CREATE TABLE states(
    id SERIAL PRIMARY KEY,
    state VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO states (state) VALUES ('Acre');
  INSERT INTO states (state) VALUES ('Alagoas');
  INSERT INTO states (state) VALUES ('Amapá');
  INSERT INTO states (state) VALUES ('Amazonas');
  INSERT INTO states (state) VALUES ('Bahia');
  INSERT INTO states (state) VALUES ('Ceará');
  INSERT INTO states (state) VALUES ('Distrito Federal');
  INSERT INTO states (state) VALUES ('Espírito Santo');
  INSERT INTO states (state) VALUES ('Goiás');
  INSERT INTO states (state) VALUES ('Maranhão');
  INSERT INTO states (state) VALUES ('Mato Grosso');
  INSERT INTO states (state) VALUES ('Mato Grosso do Sul');
  INSERT INTO states (state) VALUES ('Minas Gerais');
  INSERT INTO states (state) VALUES ('Pará');
  INSERT INTO states (state) VALUES ('Paraíba');
  INSERT INTO states (state) VALUES ('Paraná');
  INSERT INTO states (state) VALUES ('Pernambuco');
  INSERT INTO states (state) VALUES ('Piauí');
  INSERT INTO states (state) VALUES ('Rio de Janeiro');
  INSERT INTO states (state) VALUES ('Rio Grande do Norte');
  INSERT INTO states (state) VALUES ('Rio Grande do Sul');
  INSERT INTO states (state) VALUES ('Rondônia');
  INSERT INTO states (state) VALUES ('Roraima');
  INSERT INTO states (state) VALUES ('Santa Catarina');
  INSERT INTO states (state) VALUES ('São Paulo');
  INSERT INTO states (state) VALUES ('Sergipe');
  INSERT INTO states (state) VALUES ('Tocantins');
COMMIT;



-- psql -d farmamais_development -a -f myInsertFile

-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201908241700_create_table_state.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201908261300_create_table_emails_administrators.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910011232_create_table_companies.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041232_create_table_employees.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041442_create_table_ patients.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201908251658_create_table_emails_types.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201909291900_create_tables_companies_adresses.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910020900_create_table_telephones_types.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041235_create_table_employees_telephones.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041500_create_table_emails_patients.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201908261232_create_table_access_levels.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201909301232_create_table_companies_types.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910021000_create_table_companies_telephones.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041240_create_table_emails_employees.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041510_create_table_patients_telephones.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201908261232_create_table_administrators.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201909301532_create_table_companies_statuses.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910031232_create_table_employees_types.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201910041420_create_tables_patients_adresses.sql
-- psql -d farmamais_development -a -f /home/rnascimento/farmamais/sql/201911011250_create_table_recipes.sql
