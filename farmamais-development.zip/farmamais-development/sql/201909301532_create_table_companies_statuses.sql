BEGIN;
  CREATE TABLE companies_statuses (
    id SERIAL PRIMARY KEY,
    description VARCHAR
  );
COMMIT;

BEGIN;
  INSERT INTO companies_statuses VALUES (1,'Ativa');
  INSERT INTO companies_statuses VALUES (2,'Cancelada');
  INSERT INTO companies_statuses VALUES (3,'Proposta');
COMMIT;
