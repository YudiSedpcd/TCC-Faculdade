class PatientsController < ApplicationController

  # importa o helper para auxiliar no Login
  include AdministrativePatient::LoginHelper

  #indica que antes de qualquer acao passara pelo metodo do helper logged_in_user
  before_action :logged_in_patient

  layout 'administrative_patient'

end
