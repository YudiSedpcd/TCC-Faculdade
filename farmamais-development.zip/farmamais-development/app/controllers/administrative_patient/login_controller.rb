class AdministrativePatient::LoginController < LoginController

  protect_from_forgery with: :exception
  skip_before_action :verify_authenticity_token

  def login_patient
    if not session[:patient_id].nil?
      render :login_patient
    end
  end

  def authenticate_patient
    @patient = Patient.find_by(cpf: params[:login])
    password = Digest::SHA1.hexdigest(params[:password])
      if @patient && @patient.password == password

        if @patient.blocked == false
          patient_log_in @patient
          redirect_to administrative_patient_patients_path
        else
          flash[:alert] = 'Conta desativada, entrar em contato com a Farmamais'
          render :login_patient
        end

      else
        flash[:alert] = 'Combinação de login/senha incorreta'
        render :login_patient
      end
  end

  def destroy
    session.delete(:patient_id)
    @current_patient = nil
    redirect_to administrative_patient_login_login_patient_path
  end
end
