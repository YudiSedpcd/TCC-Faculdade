class AdministrativePatient::PatientsController < PatientsController

  include CheckHelper

  before_action :set_patient, only: [:edit, :update]

  def index
    @patients = Patient.find(session[:patient_id])
  end

  def edit
  end

  def update
    if @patient.update(params_patient)
      error = nil
      if params.has_key?(:confirm_password) && params[:confirm_password] != ""
        confirm_password = Digest::SHA1.hexdigest(params[:confirm_password])
        if confirm_password == @patient.password
          if params[:new_password] != '' && params[:new_password].length >= 8
            @patient.password = Digest::SHA1.hexdigest(params[:new_password])
          else
            error = 'Nova Senha não é válida (Menor que 8 Caracteres).'
          end
        else
          error = 'Senhas não conferem.'
        end
      end
      if params[:city_id] != nil
        @patient.patients_adress[0].city_id = params[:city_id]
      end
      if error.nil?
        @patient.save
        redirect_to administrative_patient_patients_path, notice: "
          #{@patient.name} foi atualizado com Sucesso.
        "
      else
        redirect_to edit_administrative_patient_patient_path(@patient.id), notice: "#{@patient.name} #{error}."
      end
    else
      render :edit
    end
  end

  def remove_patient
    @patient = Patient.find(params[:id])
    if @patient.update(blocked: true)
      redirect_to administrative_patient_login_login_patient_path, notice: "
        #{@patient.name} foi Desativada com Sucesso.
      "
    end
  end

  def change_cities
    state_id = params[:state_id]
    @cities = City.where(state_id: state_id).order(:city)
    render partial: 'state_cities', object: @cities
  end

  private

  def params_patient
    params.require(:patient).permit(
      :name,
      :cpf,
      :last_name,
      :password,
      :birth_date,
      :sexo_id,
      patients_emails_attributes: [
        :id,
        :email,
        :emails_type_id,
        :_destroy
      ],
      patients_telephones_attributes: [
        :id,
        :telephone,
        :telephones_type_id,
        :_destroy
      ],
      dependents_attributes: [
        :id,
        :name,
        :cpf,
        :last_name,
        :birth_date,
        :sexo_id,
        :holder_id,
        :_destroy
      ],
      patients_adress_attributes: [
        :id,
        :street,
        :number,
        :district,
        :city_id,
        :state_id,
        :cep,
        :_destroy
      ]
    )
  end

  def set_patient
    @patient = Patient.find(params[:id])
    @emails = @patient.patients_emails.build if @patient.patients_emails.nil?
    @emails_types = EmailsType.all
    @telephones_types = TelephonesType.all
    @states = State.all
    @sexo = Sexo.all
    @cities = City.where(state_id: @patient.patients_adress[0].state_id)
  end
end
