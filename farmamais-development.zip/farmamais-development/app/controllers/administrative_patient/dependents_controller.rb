class AdministrativePatient::DependentsController < PatientsController

  include CheckHelper

  before_action :set_dependent, only: [:edit, :update]

  def index
    @patient = Patient.find(session[:patient_id])
    @dependents = Patient.where(holder_id: session[:patient_id])
  end

  def new
    @patient = Patient.find(session[:patient_id])
    @dependent = Patient.new
    @deficiencies = Deficiency.all
    @sexo = Sexo.all
  end

  def create
    patient = Patient.find(session[:patient_id])
    dependent = Patient.new(params_dependent)
    dependent.holder_id = patient.id
    valid_cpf = check_cpf(dependent.cpf)
    dependent.created_in = Time.now
    if valid_cpf == true
      if dependent.save
        redirect_to administrative_patient_patient_patients_path, notice: "
        #{dependent.name} foi cadastrado com Sucesso."
      else
        redirect_to administrative_patient_patient_patients_path, alert: "
        #{dependent.name} não foi cadastrado."
      end
    else
      redirect_to administrative_patient_patient_patients_path, alert: "
      #{dependent.name} apresenta CPF Inválido."
    end
  end

  def edit
  end

  def update
    if @dependent.update(params_dependent)
      redirect_to administrative_patient_patient_patients_path, notice: "
        #{@dependent.name} foi atualizado com Sucesso.
      "
    else
      render :edit
    end
  end

  private

  def params_dependent
    params.require(:patient).permit(
      :name,
      :cpf,
      :last_name,
      :birth_date,
      :sexo_id,
      :description_deficiencies,
      :deficient,
      deficiency_ids: []
    )
  end

  def set_dependent
    @patient = Patient.find(session[:patient_id])
    @dependent = Patient.find(params[:id])
    @deficiencies = Deficiency.all
    @sexo = Sexo.all
  end
end
