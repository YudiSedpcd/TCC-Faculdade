class AdministrativePatient::RecipesController < PatientsController

before_action :set_recipes, only: [:edit, :update]

  def index
    patient = Patient.find(session[:patient_id])
    @recipes = Recipe.where(patient: patient.id)
  end

  def show
    @recipe = Recipe.find(params[:id])
    @recipe.quotations.each do |rq|
      if rq.approved == true
        @quotation_approve = true
      else
        @quotation_approve = false
      end
    end
  end

  def invalid_recipe
    @recipe = Recipe.find(params[:id])
    if @recipe.update(print: true)
      @recipe.quotations.each do |recipe_quotations|
        recipe_quotations.update(disapproved: true)
      end
      @recipe.quotations_requests.each do |recipe_quotations_requests|
        recipe_quotations_requests.update(active: false)
      end
      redirect_to administrative_patient_recipe_path(@recipe.id)
      flash[:notice] = "Receita Invalida"
    end
  end

  private
  def params_recipes
    params.require(:recipe).permit(:description, :doctors_prescription, :generate_quotation, :patient_id, remedies_recipes_attributes: [:id, :recipe_id, :remedy_id, :quantity, :measured_unit_id, :_destroy])
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_recipes
    @recipe = Recipe.find(params[:id])
    @remedy = @recipe.remedies_recipes.build if @recipe.remedies_recipes.nil?
    @remedies = Remedy.all
    @patients = Patient.all
    @measured_units = MeasuredUnit.all
  end
end
