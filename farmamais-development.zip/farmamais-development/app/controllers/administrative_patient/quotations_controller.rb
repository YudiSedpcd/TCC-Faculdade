class AdministrativePatient::QuotationsController < PatientsController

  before_action :set_quotations, only: [:edit, :update]

  def index
    patient = Patient.find(session[:patient_id])
    @quotation = Quotation.where(patient_id: patient.id)
  end

  def show
    @quotation = Quotation.find(params[:id])
  end

  def quotations_accept
    quotation = Quotation.find(params[:id])
    quotations_recipes = Quotation.where.not(id: quotation)
    @quotation = quotations_recipes.where(recipe_id: quotation.recipe)
    @quotation.update(disapproved:true)

    @quotation = Quotation.where(id: quotation)
    @recipe = Recipe.where(id: quotation.recipe_id)
    if @quotation.update(approved: true)
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email_quotation.rb 'quotations_accept' '#{@quotation[0].pharmacy.employees.where(employees_type_id: 3).first.employees_emails[0].email}' '#{@quotation[0].patient.name}' '#{@quotation[0].recipe.description}' 'Status Orçamento #{@quotation[0].id}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_quotation.rb 'quotations_accept' '#{@quotation[0].pharmacy.employees.where(employees_type_id: 1).first.employees_emails[0].email}' '#{@quotation[0].patient.name}' '#{@quotation[0].recipe.description}' 'Status Orçamento #{@quotation[0].id}'")
      @recipe.update(print: true)
      redirect_to administrative_patient_quotations_path, notice: "
        Orçamento #{quotation.description} Aprovado :).
      "
    end
  end

  def quotations_refuse
    @quotation = Quotation.find(params[:id])
    if @quotation.update(disapproved: true, approved:nil)
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email_quotation.rb 'quotations_refuse' '#{@quotation.pharmacy.employees.where(employees_type_id: 3).first.employees_emails[0].email}' '#{@quotation.patient.name}' '#{@quotation.recipe.description}' 'Status Orçamento #{@quotation.id}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_quotation.rb 'quotations_refuse' '#{@quotation.pharmacy.employees.where(employees_type_id: 1).first.employees_emails[0].email}' '#{@quotation.patient.name}' '#{@quotation.recipe.description}' 'Status Orçamento #{@quotation.id}'")
      redirect_to administrative_patient_quotations_path, alert: "
       Orçamento #{@quotation.description} Reprovado.
      "
    end
  end

  private
  def params_quotations
    params.require(:quotation).permit(:description, :value, :active, :approved, :disapproved, :quotations_request_id, :due_date, :recipe_id)
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_quotations
    @quotation = Quotation.find(params[:id])
  end

end
