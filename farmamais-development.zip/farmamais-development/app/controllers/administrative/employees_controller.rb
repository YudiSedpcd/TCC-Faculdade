class Administrative::EmployeesController < AdministrativeController

  before_action :set_employee, only: [:edit, :update]

  def index
    @companie = Companie.find(params[:company_id])
    @employees = Employee.where(companie_id: @companie.id)
    @employees_types = EmployeesType.all
  end

  def new
    @employees_types = EmployeesType.all
    @companie = Companie.find(params[:company_id])
    @employee = Employee.new
    @emails = @employee.employees_emails.build
    @emails_types = EmailsType.all
    @employee_telephones = @employee.employees_telephones.build
    @telephones_types = TelephonesType.all
  end

  def create
    @companie = Companie.find(params[:company_id])
    @employee = Employee.new(params_employee)
    @employee.companie_id = @companie.id
    @emails_types = EmailsType.all
    @telephones_types = TelephonesType.all
    @employees_types = EmployeesType.all
    @employee.employees_type_id = 1
    password_send_email = @employee.password
    @employee.password = Digest::SHA1.hexdigest(@employee.password)
    @employee.created_in = Time.now
    if @employee.save
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email.rb 'welcome_employee' '#{@employee.companie.fantasy_name}' '#{@employee.name}' '#{@employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@employee.employees_emails[0].email}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email.rb 'welcome_employee' '#{@employee.companie.fantasy_name}' '#{@employee.name}' '#{@employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@employee.employees_emails[0].email}'")
      redirect_to administrative_company_employees_path, notice: "
        #{@employee.name} foi cadastrado com Sucesso.
      "
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @employee.update(params_employee)
      @employee.password = Digest::SHA1.hexdigest(@employee.password)
      @employee.save
      puts @employee.errors.full_messages
        redirect_to administrative_company_employees_path, notice: "
          #{@employee.name} foi atualizado com Sucesso.
        "
    else
    puts @employee.errors.full_messages
      render :edit
    end
  end

  def lock_employee
    employee = Employee.find(params[:id])
    if employee.update(blocked: true)
      redirect_to administrative_company_employees_path, notice: "
        #{employee.name} foi bloqueado com Sucesso.
      "
    end
  end

  def unlock_employee
    employee = Employee.find(params[:id])
    if employee.update(blocked: false)
      redirect_to administrative_company_employees_path, notice: "
        #{employee.name} foi desbloqueado com Sucesso.
      "
    end
  end

  private
  def params_employee
    params.require(:employee).permit(
      :id,
      :name,
      :last_name,
      :login,
      :password,
      :blocked,
      :role,
      :employees_type_id,
      employees_emails_attributes: [
        :id,
        :email,
        :emails_type_id,
        :_destroy
      ],
      employees_telephones_attributes: [
        :id,
        :telephone,
        :telephones_type_id,
        :_destroy
      ]
    )
  end

  def set_employee
    @employees_types = EmployeesType.all
    @companie = Companie.find(params[:company_id])
    @employee = Employee.find(params[:id])
    @emails = @employee.employees_emails.build if @employee.employees_emails.nil?
    @emails_types = EmailsType.all
    @employee_telephones = @employee.employees_telephones.build if @employee.employees_telephones.nil?
    @telephones_types = TelephonesType.all
    @emails_types = EmailsType.all
  end
end
