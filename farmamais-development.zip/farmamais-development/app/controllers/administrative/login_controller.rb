class Administrative::LoginController < LoginController

  protect_from_forgery with: :exception
  skip_before_action :verify_authenticity_token

  def login_administrator
    if not session[:administrator_id].nil?
      render :login_administrator
    end
  end

  def authenticate_administrator
    @administrator = Administrator.find_by(login: params[:login])
    password = Digest::SHA1.hexdigest(params[:password])
    if @administrator && @administrator.password == password
      if @administrator.blocked == false
      adminstrador_log_in @administrator
      redirect_to administrative_administrators_path
      else
        flash[:alert] = 'Conta desativada, entrar em contato com o Administrador'
        render :login_administrator
      end
    else
      flash[:alert] = 'Combinação de login/senha incorreta'
      render :login_administrator
    end
  end

  def destroy
    session.delete(:administrator_id)
    @current_administrator = nil
    redirect_to administrative_login_login_administrator_path
  end
end
