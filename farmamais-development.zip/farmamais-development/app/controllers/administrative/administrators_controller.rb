class Administrative::AdministratorsController < AdministrativeController

  #indica que antes de chamar os metodos edit e update o metodo set_administrator sera carregado primeiro
  #assim criando as variaveis necessarias para montar a tela
  before_action :set_administrator, only: [:edit, :update]

  def index
    @administrators = Administrator.where(blocked: false) #Lista todos os Administradores
  end

  def show
    #metodo que nao esta sendo utilizado por hora, mas ja deixem ele criado nas outras controllers
  end

  def new
    @administrator = Administrator.new # Criando um obj novo de Administrator
    @emails = @administrator.administrators_emails.build # Criando um obj novo de User com base no Administrator (relacao HAS ONE = Tem Um)
    @emails_types = EmailsType.all # Lista todos os Tipos de Emails para mostrar no select da tela de edicao / cadastro
    @access_levels = AccessLevel.where(id: [1,2])
  end

  def create
    @administrator = Administrator.new(params_administrator) # Coleta os parametros do form e cria o obj administrator
    @emails_types = EmailsType.all # Lista todos os Tipos de Emails para mostrar no select da tela de edicao / cadastro
    @access_levels = AccessLevel.all
    if params[:administrator][:password] != '' && params[:administrator][:password].length >= 8
      password_send_email = @administrator.password
      @administrator.password = Digest::SHA1.hexdigest(@administrator.password)
    end
    @administrator.created_in = Time.now # Atribui o Valor de hora atual ao campo CREATED_IN
    if @administrator.save # SALVA O ADMIN
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email_administrator.rb 'welcome_admin' '#{@administrator.name}' '#{@administrator.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@administrator.administrators_emails[0].email}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_administrator.rb 'welcome_admin' '#{@administrator.name}' '#{@administrator.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@administrator.administrators_emails[0].email}'")
      # REDIRECIONA apos o save para administrative/administrator/index
      redirect_to administrative_administrators_path, notice: "
        #{@administrator.name} foi cadastrado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      render :new
    end
  end

  def edit
    # set_administrator
  end

  def update
    # set_administrator
    if @administrator.update(params_administrator) # atualiza os valor do obj
      error = nil
      if params.has_key?(:confirm_password) && params[:confirm_password] != ""
        confirm_password = Digest::SHA1.hexdigest(params[:confirm_password])
        if confirm_password == @administrator.password
          if params[:new_password] != '' && params[:new_password].length >= 8
            @administrator.password = Digest::SHA1.hexdigest(params[:new_password])
          else
            error = 'Nova Senha não é válida (Menor que 8 Caracteres).'
          end
        else
          error = 'Senhas não conferem.'
        end
      end
      if error.nil?
        @administrator.save
        # REDIRECIONA apos o update para administrative/administrator/index
        redirect_to administrative_administrators_path, notice: "
          #{@administrator.name} foi atualizado com Sucesso.
        "
      else
        redirect_to edit_administrative_administrator_path(@administrator.id), notice: "#{@administrator.name} #{error}."
      end
    else
      # caso nao salve redireciona para o form novamente.
      render :edit
    end
  end

  def block_administrator
    administrator = Administrator.find(params[:id])
    if administrator.update(blocked: true)
      redirect_to administrative_administrators_path, notice: "
        #{administrator.name} foi Desativada com Sucesso.
      "
    end
  end

  private
  # metodo que permite os paramentros do form para salvar e atualizar
  def params_administrator
    params.require(:administrator).permit(
      :name,
      :last_name,
      :login,
      :password,
      :blocked,
      :access_level_id,
      administrators_emails_attributes: [
        :id,
        :email,
        :emails_type_id,
        :_destroy
      ]
    )
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_administrator
    @administrator = Administrator.find(params[:id])
    @emails = @administrator.administrators_emails.build if @administrator.administrators_emails.nil?
    @emails_types = EmailsType.all # Lista todos os Tipos de Emails para mostrar no select da tela de edicao / cadastro
    @access_levels = AccessLevel.where(id: [1,2])
  end
end
