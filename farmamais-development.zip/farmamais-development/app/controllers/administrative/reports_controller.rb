class Administrative::ReportsController < AdministrativeController

  skip_before_action :verify_authenticity_token

  def total_recipes_generate_form
    @companies = Companie.where(
      companies_type_id: 1,
      companies_status_id: 1
    )
  end

  def total_recipes_generate_result
    companies = params[:companie_id].join(',')
    @companies = Companie.where("id IN (#{companies})")
    @recipes_total = Recipe.find_by_sql("
      SELECT
        recipes.clinic_id,
        count(distinct recipes.id) AS total_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.clinic_id IN (#{companies})
      GROUP BY
        recipes.clinic_id
    ")
    @recipes_total_auto = Recipe.find_by_sql("
      SELECT
        recipes.clinic_id,
        count(distinct recipes.id) AS total_auto_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.generate_quotation IS TRUE
        AND recipes.clinic_id IN (#{companies})
      GROUP BY
        recipes.clinic_id
    ")
    @recipes_total_no_auto = Recipe.find_by_sql("
      SELECT
        recipes.clinic_id,
        count(distinct recipes.id) AS total_no_auto_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.generate_quotation IS FALSE
        AND recipes.clinic_id IN (#{companies})
      GROUP BY
        recipes.clinic_id
    ")
  end

  def total_quotations_generate_form
    @companies = Companie.where(
      companies_type_id: 2,
      companies_status_id: 1
    )
  end

  def total_quotations_generate_result
    companies = params[:companie_id].join(',')
    @companies = Companie.where("id IN (#{companies})")
    @quotations_total = Quotation.find_by_sql("
      SELECT
        quotations.pharmacy_id,
        count(distinct quotations.id) AS total_quotations
      FROM
        quotations
      WHERE
        date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.pharmacy_id IN (#{companies})
      GROUP BY
        quotations.pharmacy_id
    ")
    @quotations_total_approved = Quotation.find_by_sql("
      SELECT
        quotations.pharmacy_id,
        count(distinct quotations.id) AS total_approved_quotations
      FROM
        quotations
      WHERE
        quotations.approved IS TRUE
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.pharmacy_id IN (#{companies})
      GROUP BY
        quotations.pharmacy_id
    ")
    @quotations_total_disapproved = Quotation.find_by_sql("
      SELECT
        quotations.pharmacy_id,
        count(distinct quotations.id) AS total_disapproved_quotations
      FROM
        quotations
      WHERE
        quotations.disapproved IS TRUE
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.pharmacy_id IN (#{companies})
      GROUP BY
        quotations.pharmacy_id
    ")
    @quotations_total_opened = Quotation.find_by_sql("
      SELECT
        quotations.pharmacy_id,
        count(distinct quotations.id) AS total_opened_quotations
      FROM
        quotations
      WHERE
        quotations.disapproved IS NULL
        AND quotations.approved IS NULL
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.pharmacy_id IN (#{companies})
      GROUP BY
        quotations.pharmacy_id
    ")
  end


end
