class Administrative::CompaniesController < AdministrativeController

  include CheckHelper

  before_action :set_companie, only: [:edit, :update, :show]

  def index
    @companies = Companie.where(companies_status_id: 1)
  end

  def clinics
    @clinics = Companie.where(companies_type_id: 1, companies_status_id: 1)
  end

  def pharmacies
    @pharmacies = Companie.where(companies_type_id: 2, companies_status_id: 1)
  end

  def new
    @companie = Companie.new # Criando um obj novo de Administrator
    @companies_statuses = CompaniesStatus.where(id: [1,3])
    @companies_types = CompaniesType.all
    @states = State.all
    @cities = City.all
    @companie_address = @companie.build_companies_address
    @companie_telephones = @companie.companies_telephones.build
    @telephones_types = TelephonesType.all
  end

  def create
    @companie = Companie.new(params_companie) # Coleta os parametros do form e cria o obj companie
    if params[:companie][:companies_type_id].to_i == 1
      @companie.color_theme = '#4169E1' #default para clinicas
    else
      @companie.color_theme = '#3CB371' #default para farmacias
    end

    valid_cnpj = check_cnpj(@companie.cnpj)

    if valid_cnpj == true
      @companie.companies_address.city_id = params[:city_id]
      @companie.created_in = Time.now # Atribui o Valor de hora atual ao campo CREATED_IN
      if @companie.save # SALVA O ADMIN
        first_employee
        # REDIRECIONA apos o save para administrative/companie/index
        redirect_to administrative_companies_path, notice: "
        #{@companie.fantasy_name} foi cadastrado com Sucesso. "
      else
        redirect_to administrative_companies_path, alert: "
        #{@companie.fantasy_name} não foi cadastrado."
      end
    else
      redirect_to new_administrative_company_path, alert: "
      #{@companie.fantasy_name} apresenta CNPJ Inválido."
    end
  end

  def recipes
    @recipes = Recipe.where(clinic_id: params[:clinic_id])
    @recipes_grafic = Recipe.find_by_sql("
      SELECT
        companies.id AS companie_id,
        companies.fantasy_name AS companie_name,
        total_recipes.total_recipes AS total_recipes,
        total_recipes_auto.total_recipes_auto AS total_recipes_auto,
        total_recipes_no_auto.total_recipes_no_auto AS total_recipes_no_auto
      FROM
        companies
      LEFT JOIN recipes ON (recipes.clinic_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(recipes.id) AS total_recipes
                  FROM
                    recipes
                  WHERE
                    recipes.clinic_id = #{params[:clinic_id]}
                )total_recipes ON (recipes.clinic_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(recipes.id) AS total_recipes_auto
                  FROM
                    recipes
                  WHERE
                    recipes.generate_quotation IS TRUE
                    AND recipes.clinic_id = #{params[:clinic_id]}
                )total_recipes_auto ON (recipes.clinic_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(recipes.id) AS total_recipes_no_auto
                  FROM
                    recipes
                  WHERE
                    recipes.generate_quotation IS FALSE
                    AND recipes.clinic_id = #{params[:clinic_id]}
                )total_recipes_no_auto ON (recipes.clinic_id = companies.id)
      WHERE
        companies.id = (#{params[:clinic_id]})
      GROUP BY
        companies.id,
        companies.fantasy_name,
        total_recipes.total_recipes,
        total_recipes_auto.total_recipes_auto,
        total_recipes_no_auto.total_recipes_no_auto
    ")
  end

  def quotations
    @quotations = Quotation.where(pharmacy_id: params[:pharmacy_id])
    @quotations_grafic = Quotation.find_by_sql("
      SELECT
        companies.id AS companie_id,
        companies.fantasy_name AS companie_name,
        total_quotations.total_quotations AS total_quotations,
        total_quotations_approve.total_quotations_approve AS total_quotations_approve,
        total_quotations_disapprove.total_quotations_disapprove AS total_quotations_disapprove,
        total_quotations_opened.total_quotations_opened AS total_quotations_opened
      FROM
        companies
      LEFT JOIN quotations ON (quotations.pharmacy_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(quotations.id) AS total_quotations
                  FROM
                    quotations
                  WHERE
                    quotations.pharmacy_id = #{params[:pharmacy_id]}
                )total_quotations ON (quotations.pharmacy_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(quotations.id) AS total_quotations_approve
                  FROM
                    quotations
                  WHERE
                    quotations.approved IS TRUE
                    AND quotations.pharmacy_id = #{params[:pharmacy_id]}
                )total_quotations_approve ON (quotations.pharmacy_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(quotations.id) AS total_quotations_disapprove
                  FROM
                    quotations
                  WHERE
                    quotations.disapproved IS TRUE
                    AND quotations.pharmacy_id = #{params[:pharmacy_id]}
                )total_quotations_disapprove ON (quotations.pharmacy_id = companies.id)
      LEFT JOIN (
                  SELECT
                    count(quotations.id) AS total_quotations_opened
                  FROM
                    quotations
                  WHERE
                    quotations.disapproved IS NULL
                    AND quotations.approved IS NULL
                    AND quotations.pharmacy_id = #{params[:pharmacy_id]}
                )total_quotations_opened ON (quotations.pharmacy_id = companies.id)
      WHERE
        companies.id = #{params[:pharmacy_id]}
      GROUP BY
        companies.id,
        companies.fantasy_name,
        total_quotations.total_quotations,
        total_quotations_approve.total_quotations_approve,
        total_quotations_disapprove.total_quotations_disapprove,
        total_quotations_opened.total_quotations_opened
    ")
  end

  def first_employee
    employee = Employee.new
    employee.name = 'Admin'
    employee.last_name = @companie.fantasy_name
    employee.role = 'Admin'
    loginOK = "admin.#{@companie.fantasy_name}".downcase
    employee.login = I18n.transliterate(loginOK)
    password_send_email = SecureRandom.alphanumeric(8)
    employee.password = Digest::SHA1.hexdigest(password_send_email)
    employee.companie_id = @companie.id
    employee.employees_type_id = 3
    employee.created_in = Time.now
    employee.save

    # system("ruby /home/rnascimento/farmamais/lib/services/send_email.rb 'welcome_employee' '#{employee.companie.fantasy_name}' '#{employee.name}' '#{employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{params[:send_email_first]}'")
    system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email.rb 'welcome_employee' '#{employee.companie.fantasy_name}' '#{employee.name}' '#{employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{params[:send_email_first]}'")
  end

  def edit
  end

  def update
    if @companie.update(params_companie) # atualiza os valor do obj
      if params[:city_id] != nil
        @companie.companies_address.update(city_id: params[:city_id])
      end
      # REDIRECIONA apos o update para administrative/administrator/index
      redirect_to administrative_companies_path, notice: "
        #{@companie.fantasy_name} foi atualizado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      render :edit
    end
  end

  def remove_companie
    @companie = Companie.find(params[:id])
    if @companie.update(companies_status_id: 2)
      redirect_to administrative_companies_path, notice: "
        #{@companie.fantasy_name} foi Desativada com Sucesso.
      "
    end
  end

  def change_cities
    state_id = params[:state_id]
    @cities = City.where(state_id: state_id).order(:city)
    render partial: 'state_cities', object: @cities
  end

  private
  # metodo que permite os paramentros do form para salvar e atualizar
  def params_companie
    params.require(:companie).permit(
      :id,
      :fantasy_name,
      :corporate_name,
      :cnpj,
      :companies_status_id,
      :companies_type_id,
      companies_address_attributes: [
        :id,
        :street,
        :number,
        :district,
        :city_id,
        :state_id,
        :cep,
        :_destroy
      ],
      companies_telephones_attributes: [
        :id,
        :telephone,
        :telephones_type_id,
        :_destroy
      ]
    )
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_companie
    @companie = Companie.find(params[:id])
    @companies_statuses = CompaniesStatus.where(id: [1,3])
    @companies_types = CompaniesType.all
    @states = State.all
    @cities = City.where(state_id: @companie.companies_address.state_id)
    @companie_address = @companie.build_companies_address if @companie.companies_address.nil?
    @companie_telephones = @companie.companies_telephones.build if @companie.companies_telephones.nil?
    @telephones_types = TelephonesType.all
  end
end
