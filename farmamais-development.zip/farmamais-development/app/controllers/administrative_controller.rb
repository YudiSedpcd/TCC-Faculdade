class AdministrativeController < ApplicationController

  # importa o helper para auxiliar no Login
  include Administrative::LoginHelper

  #indica que antes de qualquer acao passara pelo metodo do helper logged_in_adminstrator
  before_action :logged_in_adminstrator

  layout 'administrative'

end
