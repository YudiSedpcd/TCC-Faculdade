class EmployeesController < ApplicationController

  # importa o helper para auxiliar no Login
  include AdministrativeEmployee::LoginHelper

  #indica que antes de qualquer acao passara pelo metodo do helper employee_logged_in
  before_action :logged_in_employee

  layout 'administrative_employee'

end
