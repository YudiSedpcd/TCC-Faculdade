class Company::CompaniesController < ApplicationController
  def index
    @companies = Companie.all #Lista todos os Administradores
  end

  def show
    #metodo que nao esta sendo utilizado por hora, mas ja deixem ele criado nas outras controllers
  end

  def new
    @companie = Companie.new # Criando um obj novo de Administrator
  end

  # def create
  #   administrator = Administrator.new(params_administrator) # Coleta os parametros do form e cria o obj administrator
  #   administrator.created_in = Time.now # Atribui o Valor de hora atual ao campo CREATED_IN
  #   # administrator.build_user if administrator.user.nil?
  #   if administrator.save # SALVA O ADMIN
  #     # REDIRECIONA apos o save para administrative/administrator/index
  #     redirect_to administrative_administrators_path, notice: "
  #       #{administrator.name} foi cadastrado com Sucesso.
  #     "
  #   else
  #     # caso nao salve redireciona para o form novamente.
  #     render :new
  #   end
  # end

  # def edit
  #   # set_administrator
  #   @emails_types = EmailsType.all # Lista todos os Tipos de Emails para mostrar no select da tela de edicao / cadastro
  # end

  # def update
  #   # set_administrator
  #   if @administrator.update(params_administrator) # atualiza os valor do obj
  #     # REDIRECIONA apos o update para administrative/administrator/index
  #     redirect_to administrative_administrators_path, notice: "
  #       #{@administrator.name} foi atualizado com Sucesso.
  #     "
  #   else
  #     # caso nao salve redireciona para o form novamente.
  #     render :edit
  #   end
  # end

  # private
  # # metodo que permite os paramentros do form para salvar e atualizar
  # def params_administrator
  #   params.require(:administrator).permit(:name, :last_name, user_attributes: [:id, :login, :password, emails_attributes: [:id, :email, :emails_type_id, :_destroy]])
  # end

  # # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  # def set_administrator
  #   @administrator = Administrator.find(params[:id])
  #   @administrator.build_user if @administrator.user.nil?
  # end
end
