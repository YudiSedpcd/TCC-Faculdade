class SiteController < ApplicationController
  skip_before_action :verify_authenticity_token
	layout 'site'
  def index
  end

  def contact_me
    # system("ruby /home/rnascimento/farmamais/lib/services/send_contact_me.rb '#{params[:name]}' '#{params[:email]}' '#{params[:telephone]}' '#{params[:message]}'")
    system("ruby /home/gabrielazarcos/farmamais/lib/services/send_contact_me.rb '#{params[:name]}' '#{params[:email]}' '#{params[:telephone]}' '#{params[:message]}'")
    flash[:notice] = 'Enviado com Sucesso'
    redirect_to site_path
  end
end
