class LoginController < ApplicationController

  # importa o helper para auxiliar no Login (administrador / employee / patient)
  include Administrative::LoginHelper
  include AdministrativeEmployee::LoginHelper
  include AdministrativePatient::LoginHelper

end
