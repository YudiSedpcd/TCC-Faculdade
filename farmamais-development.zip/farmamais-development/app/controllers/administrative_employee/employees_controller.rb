class AdministrativeEmployee::EmployeesController < EmployeesController

  before_action :set_employee, only: [:edit, :update]

  def index
    employee_login = Employee.find(session[:employee_id])
    @employees = Employee.where(companie_id: employee_login.companie_id)
  end

  def show
  end

  def new
    @employee = Employee.new
    @emails = @employee.employees_emails.build
    @telephones = @employee.employees_telephones.build
    @employees_types = EmployeesType.all
    @emails_types = EmailsType.all
    @telephones_types = TelephonesType.all
  end

  def create
    @employees_types = EmployeesType.all
    @emails_types = EmailsType.all
    @telephones_types = TelephonesType.all
    employee_login = Employee.find(session[:employee_id])
    @employee = Employee.new(params_employee)
    password_send_email = @employee.password
    @employee.password = Digest::SHA1.hexdigest(password)
    @employee.companie_id = employee_login.companie_id
    @employee.created_in = Time.now
    if @employee.save
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email.rb 'welcome_employee' '#{@employee.companie.fantasy_name}' '#{@employee.name}' '#{@employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@employee.employees_emails[0].email}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email.rb 'welcome_employee' '#{@employee.companie.fantasy_name}' '#{@employee.name}' '#{@employee.login}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{@employee.employees_emails[0].email}'")
      redirect_to administrative_employee_employees_path, notice: "
        #{@employee.name} foi cadastrado com Sucesso.
      "
    else
      render :new
    end
  end

  def edit
  end

  def update
    if @employee.update(params_employee)
      @employee.password = Digest::SHA1.hexdigest(@employee.password)
      @employee.save
      redirect_to administrative_employee_employees_path, notice: "
        #{@employee.name} foi atualizado com Sucesso.
      "
    else
      render :edit
    end
  end

  private

  def params_employee
    params.require(:employee).permit(
      :id,
      :name,
      :last_name,
      :login,
      :password,
      :blocked,
      :role,
      :employees_type_id,
      employees_emails_attributes: [
        :id,
        :email,
        :emails_type_id,
        :created_in,
        :_destroy
      ],
      employees_telephones_attributes: [
        :id,
        :telephone,
        :telephones_type_id,
        :_destroy
      ]
    )
  end

  def set_employee
    @employee = Employee.find(params[:id])
    @emails = @employee.employees_emails.build if @employee.employees_emails.nil?
    @employee_telephones = @employee.employees_telephones.build if @employee.employees_telephones.nil?
    @emails_types = EmailsType.all
    @telephones_types = TelephonesType.all
    @employees_types = EmployeesType.all
  end
end
