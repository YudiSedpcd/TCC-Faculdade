class AdministrativeEmployee::QuotationsController < EmployeesController

  before_action :set_quotations, only: [:edit, :update]

  def index
    employee = Employee.find(session[:employee_id])
    @quotation = Quotation.where(pharmacy_id: employee.companie.id)
  end

  def show
    @quotation = Quotation.find(params[:id])
  end

  def new
    @quotations_request = QuotationsRequest.find(params[:quotations_request_id])
    @quotation = Quotation.new
  end

  def create
    quotations_request = QuotationsRequest.find(params[:quotations_request_id])
    quotation = Quotation.new(params_quotations)
    quotation.active = true
    quotation.quotations_request_id = quotations_request.id
    quotation.employee_id = session[:employee_id]
    quotation.pharmacy_id = quotations_request.pharmacy_id
    quotation.recipe_id = quotations_request.recipe_id
    quotation.clinic_id = quotations_request.clinic_id
    quotation.patient_id = quotations_request.patient_id
    quotation.created_in = Time.now # Atribui o Valor de hora atual ao campo CREATED_IN
    companie = Companie.find(quotations_request.pharmacy_id)
    # administrator.build_user if administrator.user.nil?
    if quotation.save # SALVA O ORCAMENTO
      quotations_request.update(generate_quotation: true)
      # system("ruby /home/rnascimento/farmamais/lib/services/send_email_recipe.rb 'new_quotation' '#{quotations_request.patient.name}' '#{quotations_request.recipe.description}' '#{companie.fantasy_name}' '#{quotations_request.patient.patients_emails[0].email}'")
      system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_recipe.rb 'new_quotation' '#{quotations_request.patient.name}' '#{quotations_request.recipe.description}' '#{companie.fantasy_name}' '#{quotations_request.patient.patients_emails[0].email}'")
      # REDIRECIONA apos o save para administrative/administrator/index
      redirect_to administrative_employee_quotations_path, notice: "
        #{quotation.description} foi cadastrado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      p 'OOOOOOOOOOOOOOOOOOOOOO'
      p quotation.errors.full_messages
      redirect_to administrative_employee_quotations_path, alert: " Orçamento
      #{quotation.description} não foi cadastrado."
    end
  end

  def edit
  end

  def update
    p 'OPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPO'
    p 'OPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPO'
    if @quotation.update(params_quotations)
      redirect_to administrative_employee_quotations_path, notice: "
        #{@quotation.description} foi atualizado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      render :edit
    end
  end

  private
  def params_quotations
    params.require(:quotation).permit(:description, :value, :active, :approved, :disapproved, :quotations_request_id, :due_date)
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_quotations
    @quotation = Quotation.find(params[:id])
  end
end
