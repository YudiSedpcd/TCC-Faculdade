class AdministrativeEmployee::PatientsController < EmployeesController

  include CheckHelper

  before_action :set_patient, only: [:edit, :update]

  def new
    @patient = Patient.new
    @patients_dependents = @patient.dependents.build
    @sexo = Sexo.all
    @emails = @patient.patients_emails.build
    @emails_types = EmailsType.all
    @patient_telephones = @patient.patients_telephones.build
    @telephones_types = TelephonesType.all
    @patient_adresses = @patient.patients_adress.build
    @telephones_types = AdressesType.all
    @states = State.all
    @cities = City.all
    @deficiencies = Deficiency.all
  end

  def create
    send_email = ''
    patient = Patient.new(params_patient)
    valid_cpf = check_cpf(patient.cpf)
    if patient.patients_emails
      patient.patients_emails.each do |email|
        email.created_in = Time.now
        send_email = email.email
      end
    end
    if patient.patients_telephones
       patient.patients_telephones.each do |telefone|
       telefone.created_in = Time.now
      end
    end
    patient.created_in = Time.now
     if valid_cpf == true
      patient.patients_adress[0].city_id = params[:city_id]
      password_send_email = SecureRandom.alphanumeric(8)
      patient.password = Digest::SHA1.hexdigest(password_send_email)
      if patient.save
        p patient.errors.full_messages
        redirect_to administrative_employee_employees_path, notice: "
        #{patient.name} foi cadastrado com Sucesso."
        # system("ruby /home/rnascimento/farmamais/lib/services/send_email_patient.rb 'welcome_patient' '#{patient.name}' '#{patient.cpf}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{send_email}'")
        system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_patient.rb 'welcome_patient' '#{patient.name}' '#{patient.cpf}' '#{password_send_email}' 'Bem Vindo a Farma+' '#{send_email}'")
      else
        p patient.errors.full_messages
        redirect_to administrative_employee_employees_path, alert: "
        #{patient.name} não foi cadastrado."
      end
     else
       p patient.errors.full_messages
       redirect_to administrative_employee_employees_path, alert: "
       #{patient.name} apresenta CPF Inválido."
     end

  end

  def change_cities
    state_id = params[:state_id]
    @cities = City.where(state_id: state_id).order(:city)
    render partial: 'state_cities', object: @cities
  end

  private

  def params_patient
    params.require(:patient).permit(
      :name,
      :cpf,
      :last_name,
      :password,
      :birth_date,
      :sexo_id,
      patients_emails_attributes: [
        :id,
        :email,
        :emails_type_id,
        :_destroy
      ],
      patients_telephones_attributes: [
        :id,
        :telephone,
        :telephones_type_id,
        :_destroy
      ],
      dependents_attributes: [
        :id,
        :name,
        :cpf,
        :last_name,
        :birth_date,
        :sexo_id,
        :holder_id,
        :_destroy,
        :description_deficiencies,
        :deficient,
        deficiency_ids: []
      ],
      patients_adress_attributes: [
        :id,
        :street,
        :number,
        :district,
        :city_id,
        :state_id,
        :cep,
        :_destroy
      ]
    )
  end
end
