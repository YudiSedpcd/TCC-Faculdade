class AdministrativeEmployee::RecipesController < EmployeesController

  include CheckHelper

  before_action :set_recipes, only: [:edit, :update]

  def index
    employee = Employee.find(session[:employee_id])
    @recipes = Recipe.where(clinic_id: employee.companie.id)
  end

  def show
    @recipe = Recipe.find(params[:id])
    @recipe.quotations.each do |rq|
      if rq.approved == true
        @quotation_approve = true
      else
        @quotation_approve = false
      end
    end
  end

  def invalid_recipe
    @recipe = Recipe.find(params[:id])
    if @recipe.update(print: true, generate_quotation:false)
      @recipe.quotations.each do |recipe_quotations|
        recipe_quotations.update(disapproved: true)
      end
      @recipe.quotations_requests.each do |recipe_quotations_requests|
        recipe_quotations_requests.update(active: false)
      end
      redirect_to administrative_employee_recipe_path(@recipe.id)
      flash[:notice] = "Receita Invalida"
    end
  end

  def new
    @recipe = Recipe.new
    @remedy = @recipe.remedies_recipes.build
    @remedies = Remedy.all
    @measured_units = MeasuredUnit.all
    @patients = Patient.where(id: params[:param_1])
  end

  def search
    cpf_patient = params[:cpf]
    valid_cpf = check_cpf(cpf_patient)
    @patients = Patient.where(cpf: cpf_patient, blocked: false)

      patient = @patients.each do |patient|
        if patient.cpf == cpf_patient
          redirect_to new_administrative_employee_recipe_path(param_1:patient.id)
        end
      end

      if valid_cpf == true
        if patient == []
          redirect_to new_administrative_employee_patient_path
          flash[:alert] = " #{cpf_patient}, Paciente não está cadastrado"
        end
      end
  end

  def send_to_quotation(clinic_id, patient_id, employee_id, recipe_id)
    '+++++++++++++++++++ SEND TO quotation +++++++++++++++++++'
    patient = Patient.find(patient_id)
    if patient.holder_id == nil
      patient_city_id = patient.patients_adress[0].city_id
    else
      patient_city_id = patient.holder.patients_adress[0].city_id
    end
      pharmacies = Companie.joins(
        :companies_address
        ).where(
        companies: {
          companies_type_id: 2,
          companies_status_id: 1
        },
        companies_adresses: {
          city_id: patient_city_id
        }
      )
    pharmacies.each do |pharmacy|
      quotations_requests = QuotationsRequest.new
      quotations_requests.clinic_id = clinic_id
      quotations_requests.patient_id = patient_id
      quotations_requests.employee_id = employee_id
      quotations_requests.recipe_id = recipe_id
      quotations_requests.pharmacy_id = pharmacy.id
      quotations_requests.generate_quotation = false
      quotations_requests.created_in = Time.now()
      if quotations_requests.save
        # system("ruby /home/rnascimento/farmamais/lib/services/send_email_quotation.rb 'new_quotation_request' '#{pharmacy.employees.where(employees_type_id: 3).first.employees_emails[0].email}' '' '' 'Nova Solicitação de Orçamento'")
        system("ruby /home/gabrielazarcos/farmamais/lib/services/send_email_quotation.rb 'new_quotation_request' '#{pharmacy.employees.where(employees_type_id: 1).first.employees_emails[0].email}' '' '' 'Nova Solicitação de Orçamento'")
      else
        quotation.errors.full_messages
      end
    end
  end

  def create
    employee = Employee.find(session[:employee_id])
    recipe = Recipe.new(params_recipes) # Coleta os parametros do form e cria o obj receita
    recipe.created_in = Time.now() # Atribui o Valor de hora atual ao campo CREATED_IN
    recipe.clinic_id = employee.companie.id
    recipe.employee_id = employee.id
    if recipe.save
      if recipe.generate_quotation == true
        send_to_quotation(recipe.clinic_id, recipe.patient_id, employee.id, recipe.id)
      end
      redirect_to administrative_employee_employees_path, notice: "
        #{recipe.description} foi cadastrado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      redirect_to administrative_employee_employees_path
    end
  end

  def edit
  end

  def update
    p 'OPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPO'
    p params[:recipe][:remedies_recipes_attributes]
    p 'OPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPOPO'
    if @recipe.update(params_recipes)
      redirect_to administrative_employee_recipes_path, notice: "
        #{@recipe.description} foi atualizado com Sucesso.
      "
    else
      # caso nao salve redireciona para o form novamente.
      render :edit
    end
  end

  private
  def params_recipes
    params.require(:recipe).permit(:patient, :description, :doctors_prescription, :generate_quotation, :patient_id, remedies_recipes_attributes: [:id, :recipe_id, :remedy_id, :quantity, :measured_unit_id, :_destroy])
  end

  # metodo que evita a replicacao das duas variaveis abaixo nos metodos edit e update
  def set_recipes
    @recipe = Recipe.find(params[:id])
    @remedy = @recipe.remedies_recipes.build if @recipe.remedies_recipes.nil?
    @remedies = Remedy.all
    @patients = Patient.all
    @measured_units = MeasuredUnit.all
  end
end
