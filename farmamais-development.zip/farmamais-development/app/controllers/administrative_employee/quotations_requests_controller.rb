class AdministrativeEmployee::QuotationsRequestsController < EmployeesController

  def index
    employee = Employee.find(session[:employee_id])
    @quotations_requests = QuotationsRequest.where(pharmacy_id: employee.companie.id, generate_quotation: false, active: true)
  end

  def show
    @quotation_request = QuotationsRequest.find(params[:id])
  end

end
