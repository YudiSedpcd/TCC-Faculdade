class AdministrativeEmployee::ReportsController < EmployeesController

  skip_before_action :verify_authenticity_token

  def recipes_medics
    @medics = Employee.where(
      employees_type_id: 1,
      companie_id: @current_employee.companie.id
    )
  end

  def recipes_medics_result
    medics = params[:medics_id].join(',')
    @medics = Employee.where("id IN (#{medics})")

    @recipes_total = Recipe.find_by_sql("
      SELECT
        recipes.employee_id,
        count(distinct recipes.id) AS total_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.employee_id IN (#{medics})
      GROUP BY
        recipes.employee_id
    ")
    @recipes_total_auto = Recipe.find_by_sql("
      SELECT
        recipes.employee_id,
        count(distinct recipes.id) AS total_auto_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.generate_quotation IS TRUE
        AND recipes.employee_id IN (#{medics})
      GROUP BY
        recipes.employee_id
    ")
    @recipes_total_no_auto = Recipe.find_by_sql("
      SELECT
        recipes.employee_id,
        count(distinct recipes.id) AS total_no_auto_recipes
      FROM
        recipes
      WHERE
        date_trunc('day', recipes.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', recipes.created_in) <= '#{params[:end_date]}'
        AND recipes.generate_quotation IS FALSE
        AND recipes.employee_id IN (#{medics})
      GROUP BY
        recipes.employee_id
    ")
  end

  def quotation_employees
    @employees = Employee.where(
      "employees_type_id IN (2,3) AND companie_id = #{@current_employee.companie.id}"
    )
  end

  def quotation_employees_result
    employees = params[:employees_id].join(',')
    @employees = Employee.where("id IN (#{employees})")
    @quotations_total = Quotation.find_by_sql("
      SELECT
        quotations.employee_id,
        count(distinct quotations.id) AS total_quotations
      FROM
        quotations
      WHERE
        date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.employee_id IN (#{employees})
      GROUP BY
        quotations.employee_id
    ")
    @quotations_total_approved = Quotation.find_by_sql("
      SELECT
        quotations.employee_id,
        count(distinct quotations.id) AS total_approved_quotations
      FROM
        quotations
      WHERE
        quotations.approved IS TRUE
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.employee_id IN (#{employees})
      GROUP BY
        quotations.employee_id
    ")
    @quotations_total_disapproved = Quotation.find_by_sql("
      SELECT
        quotations.employee_id,
        count(distinct quotations.id) AS total_disapproved_quotations
      FROM
        quotations
      WHERE
        quotations.disapproved IS TRUE
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.employee_id IN (#{employees})
      GROUP BY
        quotations.employee_id
    ")
    @quotations_total_opened = Quotation.find_by_sql("
      SELECT
        quotations.employee_id,
        count(distinct quotations.id) AS total_opened_quotations
      FROM
        quotations
      WHERE
        quotations.disapproved IS NULL
        AND quotations.approved IS NULL
        AND date_trunc('day', quotations.created_in) >= '#{params[:start_date]}'
        AND date_trunc('day', quotations.created_in) <= '#{params[:end_date]}'
        AND quotations.employee_id IN (#{employees})
      GROUP BY
        quotations.employee_id
    ")
  end


end
