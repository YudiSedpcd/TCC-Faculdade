class AdministrativeEmployee::LoginController < LoginController

  protect_from_forgery with: :exception
  skip_before_action :verify_authenticity_token

  def login_employee
    if not session[:employee_id].nil?
      render :login_employee
    end
  end

  def authenticate_employee
    @employee = Employee.find_by(login: params[:login])
    password = Digest::SHA1.hexdigest(params[:password])
    if @employee && @employee.password == password
      if @employee.companie.companies_status_id != 2
        if @employee.blocked == false
          employee_log_in @employee
          redirect_to administrative_employee_employees_path
        else
          flash[:alert] = 'Conta desativada, entrar em contato com o Administrador'
          render :login_employee
        end
      else
        flash[:alert] = 'Empresas desativada'
        render :login_employee
      end
    else
      flash[:alert] = 'Combinação de login/senha incorreta'
      render :login_employee
    end

  end

  def destroy
    session.delete(:employee_id)
    @current_employee = nil
    redirect_to administrative_employee_login_login_employee_path
  end
end
