class AdressesType < ApplicationRecord
  has_many :patients_adresses
end
