class EmailsType < ApplicationRecord
  has_many :emails
end
