class User < ApplicationRecord

  # Realacao pertence a (adminstrator)/ informa a class / informa que a chave estrangeira e o profile_id / o inverse_of indica para o rails o caminho reverso EX.(administrator.user)
  belongs_to :administrator, class_name: :Administrator, foreign_key: :profile_id, inverse_of: :user
  belongs_to :employee, class_name: :Employee, foreign_key: :profile_id, inverse_of: :user
  belongs_to :patient, class_name: :Patient, foreign_key: :profile_id, inverse_of: :user

  # relacao tem muitos (emails) / mapeia o caminho reverso emails.user, destroy permite remover os obj salvos.
  has_many :emails, inverse_of: :user, dependent: :destroy

  # aqui permite salvarmos/atualizarmos os atribuitos EMAIL e EMAILS_TYPE presentes na table emails
  accepts_nested_attributes_for :emails, reject_if: :all_blank, allow_destroy: true
end
