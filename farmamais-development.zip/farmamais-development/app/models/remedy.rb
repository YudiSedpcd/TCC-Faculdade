class Remedy < ApplicationRecord
  has_many :remedies_recipes, dependent: :destroy
  has_many :recipes , through: :remedies_recipes

  # accepts_nested_attributes_for :remedies_recipes, reject_if: :all_blank, allow_destroy: true
  # accepts_nested_attributes_for :recipes, reject_if: :all_blank, allow_destroy: true
end
