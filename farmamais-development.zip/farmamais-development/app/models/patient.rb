class Patient < ApplicationRecord

  has_many :quotations_requests
  has_many :quotations
  has_many :recipes
  has_many :patients_emails, inverse_of: :patient, dependent: :destroy
  has_many :patients_telephones, inverse_of: :patient, dependent: :destroy
  has_many :patients_adress, inverse_of: :patient, dependent: :destroy
  has_many :dependents, class_name: 'Patient', foreign_key: 'holder_id'

  has_and_belongs_to_many :deficiencies

  belongs_to :holder, class_name: 'Patient', optional: true
  belongs_to :sexo

  accepts_nested_attributes_for :patients_emails, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :patients_telephones, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :patients_adress, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :dependents, reject_if: :all_blank, allow_destroy: true

  validates :cpf, uniqueness: true

end
