class CompaniesStatus < ApplicationRecord
  has_many :companies
end
