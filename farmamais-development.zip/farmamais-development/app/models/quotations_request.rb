class QuotationsRequest < ApplicationRecord
  belongs_to :clinic, class_name: 'Companie', foreign_key: 'clinic_id'
  belongs_to :recipe
  belongs_to :patient
  belongs_to :employee

  has_many :quotations
end
