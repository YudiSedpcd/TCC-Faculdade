class Quotation < ApplicationRecord
  belongs_to :clinic, class_name: 'Companie', foreign_key: 'clinic_id'
  belongs_to :pharmacy, class_name: 'Companie', foreign_key: 'pharmacy_id'
  belongs_to :recipe
  belongs_to :patient
  belongs_to :employee
  belongs_to :quotations_request
end
