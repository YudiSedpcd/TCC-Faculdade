class CompaniesTelephone < ApplicationRecord
  belongs_to :companie, inverse_of: :companies_telephones, optional: true
  belongs_to :telephones_type

  after_initialize :set_created_in, on: :create

  def set_created_in
    self.created_in = Time.now
  end
end
