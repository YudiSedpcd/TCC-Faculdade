class EmployeesType < ApplicationRecord
  has_many :employees
end
