class MeasuredUnit < ApplicationRecord
  has_many :remedies_recipes
end
