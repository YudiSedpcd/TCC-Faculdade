class Sexo < ApplicationRecord
  has_many :patients
end
