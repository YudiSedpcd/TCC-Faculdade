class AdministratorsEmail < ApplicationRecord
  # relacao email pertence a user / inverse_of mapeia o caminho inverso user.emails / optinal true torna o obj opcional
  belongs_to :administrator, inverse_of: :administrators_emails, optional: true
  belongs_to :emails_type

  validates :email, uniqueness: true

  after_initialize :set_created_in, on: :create

  def set_created_in
    self.created_in = Time.now
  end
end
