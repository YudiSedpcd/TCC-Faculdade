class PatientsAdress < ApplicationRecord
  self.table_name = 'patients_adresses'

  belongs_to :state

  belongs_to :patient, inverse_of: :patients_adress, optional: true
end
