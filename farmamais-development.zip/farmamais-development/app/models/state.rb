class State < ApplicationRecord
  has_many :patients_adresses
  has_many :companies_adresses
  has_many :cities
end
