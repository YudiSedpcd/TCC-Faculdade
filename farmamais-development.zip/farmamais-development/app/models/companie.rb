class Companie < ApplicationRecord
  belongs_to :companies_type
  belongs_to :companies_status

  has_one :companies_address, inverse_of: :companie, dependent: :destroy

  has_many :employees
  has_many :quotations_requests
  has_many :quotations
  has_many :recipes
  has_many :companies_telephones, inverse_of: :companie, dependent: :destroy

  accepts_nested_attributes_for :companies_telephones, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :companies_address, reject_if: :all_blank, allow_destroy: true

  validate :validations
  validates :cnpj, uniqueness: true

  def validations
    errors[:base] << 'Nome Fantasia não pode ser deixado em branco' if fantasy_name.blank?
    errors[:base] << 'Razão Social não pode ser deixado em branco' if corporate_name.blank?
    errors[:base] << 'CNPJ não pode ser deixado em branco' if cnpj.blank?
  end

end
