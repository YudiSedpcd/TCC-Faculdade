class PatientsDependent < ApplicationRecord

end
