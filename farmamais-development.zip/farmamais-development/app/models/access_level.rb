class AccessLevel < ApplicationRecord
  has_many :administrators
end
