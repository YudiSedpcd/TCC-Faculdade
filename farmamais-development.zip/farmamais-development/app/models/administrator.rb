class Administrator < ApplicationRecord
  # Realacao tem um (user) / informa que a chave estrangeira e o profile_id / o inverse_of indica para o rails o caminho reverso EX.(user.administrator)
  # has_one :user, foreign_key: 'profile_id',  inverse_of: :administrator

  # aqui permite salvarmos/atualizarmos os atribuitos LOGIN e PASSWORD presentes na table users
  # accepts_nested_attributes_for(:user, update_only: true)

  # relacao tem muitos (emails) / mapeia o caminho reverso emails.user, destroy permite remover os obj salvos.
  has_many :administrators_emails, inverse_of: :administrator, dependent: :destroy

  belongs_to :access_level, optional: true

  # aqui permite salvarmos/atualizarmos os atribuitos EMAIL e EMAILS_TYPE presentes na table emails
  accepts_nested_attributes_for :administrators_emails, reject_if: :all_blank, allow_destroy: true

  validate :validations
  validates :login, uniqueness: true

  def validations
    errors[:base] << 'Nome não pode ser deixado em branco' if name.blank?
    errors[:base] << 'Nome não pode ser menor que 3 caracteres' if name.length < 3
    errors[:base] << 'Sobrenome não pode ser deixado em branco' if last_name.blank?
    errors[:base] << 'Sobrenome não pode ser menor que 3 caracteres' if last_name.length < 3
    errors[:base] << 'Login não pode ser deixado em branco' if login.blank?
    errors[:base] << 'Login não pode ser menor que 3 caracteres' if login.length < 3
    errors[:base] << 'Senha não pode ser deixado em branco' if password.blank?
    errors[:base] << 'Login não pode ser menor que 8 caracteres' if password.length < 8
    errors[:base] << 'Nível não pode ser deixado em branco' if access_level_id.blank?
  end
end
