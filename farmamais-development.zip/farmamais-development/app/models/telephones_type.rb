class TelephonesType < ApplicationRecord
  has_many :patients_telephones
  has_many :employees_telephones
  has_many :companies_telephones
end
