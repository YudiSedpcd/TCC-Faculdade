class CompaniesAddress < ApplicationRecord
  self.table_name = 'companies_adresses'

  belongs_to :state
  belongs_to :companie, inverse_of: :companies_address, optional: true
end
