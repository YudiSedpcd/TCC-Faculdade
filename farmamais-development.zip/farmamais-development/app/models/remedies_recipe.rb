class RemediesRecipe < ApplicationRecord
  belongs_to :remedy
  belongs_to :recipe
  belongs_to :measured_unit

  # accepts_nested_attributes_for :remedies_recipes, reject_if: :all_blank, allow_destroy: true
  # accepts_nested_attributes_for :remedies, reject_if: :all_blank, allow_destroy: true
end
