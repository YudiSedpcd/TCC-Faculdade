class Employee < ApplicationRecord
  belongs_to :companie
  belongs_to :employees_type

  # relacao tem muitos (emails) / mapeia o caminho reverso emails.user, destroy permite remover os obj salvos.
  has_many :employees_emails, inverse_of: :employee, dependent: :destroy
  has_many :employees_telephones, inverse_of: :employee, dependent: :destroy
  has_many :quotations
  has_many :quotations_requests

  # aqui permite salvarmos/atualizarmos os atribuitos EMAIL e EMAILS_TYPE presentes na table emails
  accepts_nested_attributes_for :employees_emails, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :employees_telephones, reject_if: :all_blank, allow_destroy: true

  validate :validations
  validates :login, uniqueness: true

  def validations
    errors[:base] << 'Nome não pode ser deixado em branco' if name.blank?
    errors[:base] << 'Nome não pode ser menor que 3 caracteres' if name.length < 3
    errors[:base] << 'Sobrenome não pode ser deixado em branco' if last_name.blank?
    errors[:base] << 'Sobrenome não pode ser menor que 3 caracteres' if last_name.length < 3
    errors[:base] << 'Login não pode ser deixado em branco' if login.blank?
    errors[:base] << 'Login não pode ser menor que 3 caracteres' if login.length < 3
    errors[:base] << 'Senha não pode ser deixado em branco' if password.blank?
    errors[:base] << 'Login não pode ser menor que 8 caracteres' if password.length < 8
    errors[:base] << 'Especialização não pode ser deixado em branco' if role.blank?
  end
end
