class CompaniesType < ApplicationRecord
  has_many :companies
end
