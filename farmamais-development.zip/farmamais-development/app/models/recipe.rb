class Recipe < ApplicationRecord
  belongs_to :clinic, class_name: 'Companie', foreign_key: 'clinic_id'
  belongs_to :patient
  belongs_to :employee
  has_many :remedies_recipes, dependent: :destroy
  has_many :remedies , through: :remedies_recipes
  has_many :quotations_requests
  has_many :quotations

  accepts_nested_attributes_for :remedies_recipes, reject_if: :all_blank, allow_destroy: true
  # accepts_nested_attributes_for :remedies, reject_if: :all_blank, allow_destroy: true
end
