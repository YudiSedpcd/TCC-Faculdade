module AdministrativePatient::LoginHelper
  def patient_log_in(patient)
    session[:patient_id] = patient.id
  end

  # Returns the current logged-in patient (if any).
  def current_patient
    @current_patient ||= Patient.find_by(id: session[:patient_id])
  end

  # Returns true if the patient is logged in, false otherwise.
  def patient_logged_in?
    !current_patient.nil?
  end

  # Confirms a logged-in patient or redirect
  def logged_in_patient
    if !patient_logged_in?
      flash[:danger] = "Please log in."
      redirect_to administrative_patient_login_login_employee_path
    end
  end
end
