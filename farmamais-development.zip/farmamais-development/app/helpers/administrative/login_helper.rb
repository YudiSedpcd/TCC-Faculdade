module Administrative::LoginHelper
  def adminstrador_log_in(administrator)
    session[:administrator_id] = administrator.id
  end

  def current_administrator
    @current_administrator ||= Administrator.find_by(id: session[:administrator_id])
  end

  def adminstrator_logged_in?
    !current_administrator.nil?
  end

  def logged_in_adminstrator
    if !adminstrator_logged_in?
      flash[:danger] = "Por favor, Faça o login."
      redirect_to administrative_login_login_administrator_path
    end
  end
end
