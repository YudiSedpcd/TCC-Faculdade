module AdministrativeEmployee::LoginHelper
  def employee_log_in(employee)
    session[:employee_id] = employee.id
  end

  # Returns the current logged-in employee (if any).
  def current_employee
    @current_employee ||= Employee.find_by(id: session[:employee_id])
  end

  # Returns true if the employee is logged in, false otherwise.
  def employee_logged_in?
    !current_employee.nil?
  end

  # Confirms a logged-in employee or redirect
  def logged_in_employee
    if !employee_logged_in?
      flash[:danger] = "Please log in."
      redirect_to administrative_employee_login_login_employee_path
    end
  end
end
